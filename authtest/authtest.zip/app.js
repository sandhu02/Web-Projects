const express = require('express')
const mongoose = require('mongoose')
const cookieParser = require('cookie-parser');
require('dotenv').config();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken')
const app = express()

app.use(express.urlencoded({ extended: true }));
app.use(cookieParser())
app.set('view engine', 'ejs');

const PORT = process.env.PORT || 3000
app.listen(PORT , () => {console.log(`Server running on port ${PORT}`)})

mongoose.connect(process.env.MONGODB_CONNECTION, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => {
    console.log("MongoDB connected successfully");
})
.catch((err) => {
    console.error("MongoDB connection error:", err);
});

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
});
const User = mongoose.model('users', userSchema);


app.get("/" , (req,res) => {
    res.render("login.ejs")
})

app.get("/signupPage" , (req,res) => {
    res.render("register.ejs")
})

app.post("/register" , async (req,res)=> {
    const {name, username, password} = req.body

    const alreadyExists = await User.findOne({username})
    if (alreadyExists){ res.send("User already exists") } 

    const hash = await bcrypt.hash(password, 10);
    try {
        await User.create({ name, username, password: hash });
        res.redirect('/');
    } catch (err) {
        res.status(400).send('User already exists');
    }
})

app.post("/login" ,async (req ,res) => {
    const {username , password} = req.body

    const mongodbUser = await User.findOne( {username} );
    if (!mongodbUser) return res.status(400).send('User not found');

    const isMatch = await bcrypt.compare(password, mongodbUser.password);
    
    if(!isMatch){
        res.send("incorrect password")
    }
    
    const token = jwt.sign({ id: mongodbUser._id }, process.env.JWT_SECRET, { expiresIn: '30s' });
    res.cookie('token', token, { httpOnly: true });
    res.redirect('/home');
})

app.get("/home", verifyCookie, async (req,res)=>{
    const user = await User.findById(req.user.id)
    res.render("home.ejs",{user : user})
})


function verifyCookie(req,res,next){
    const token = req.cookies.token
    jwt.verify(token , process.env.JWT_SECRET , (err,user)=>{
        if (err){
            res.redirect("/")
        }
        else {
            req.user = user
            next()
        }
    })
    
}